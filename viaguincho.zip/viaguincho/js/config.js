/* Configuração dos mapas. Edite aqui.
 * MAP_PROVIDER: 'leaflet' (OpenStreetMap, gratuito) ou 'google' (exige chave).
 * GOOGLE_MAPS_API_KEY: chave do "Maps JavaScript API". Chaves de navegador são públicas por natureza:
 *   RESTRINJA no Google Cloud Console por domínio (HTTP referrers) e apenas ao Maps JavaScript API. Veja o README. */
window.REBOCA_CONFIG = Object.assign({ MAP_PROVIDER: 'leaflet', GOOGLE_MAPS_API_KEY: '' }, window.REBOCA_CONFIG || {});
