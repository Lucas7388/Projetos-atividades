'use strict';
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const KEY = 'ViaGuincho.rascunho', SES = 'ViaGuincho.sessao-demo';
const load = k => { try { return JSON.parse(sessionStorage.getItem(k)); } catch { return null; } };
const save = (k, v) => { try { sessionStorage.setItem(k, JSON.stringify(v)); } catch {} };
const STATUS = [
  ['Solicitação enviada', 'Recebemos seu pedido.'],
  ['Procurando um guincho disponível', 'Estamos buscando um prestador.'],
  ['Guincho confirmado', 'Um prestador aceitou o atendimento (simulado).'],
  ['Prestador a caminho', 'O guincho está a caminho (simulado).'],
  ['Guincho chegou ao local', 'O prestador chegou (simulado).'],
  ['Atendimento concluído', 'Serviço concluído. Obrigado!']];
let draft = load(KEY) || {}, user = load(SES), step = 0, trackIdx = 0, mode = 'login', view = 'home', heroSeen = true;

// ---- Mapas (Leaflet + OSM). Sem Leaflet, a interface continua funcionando sem mapa ----
// ---- Mapas: camada js/maps.js (Leaflet/OpenStreetMap ou Google Maps, conforme js/config.js e o seletor) ----
const maps = {}, pend = {};
function mk(id) {
  if (maps[id]) return Promise.resolve(maps[id]);
  return pend[id] ||= Maps.create(id, id === 'map-track' ? 'topright' : 'bottomright').then(h => {
    delete pend[id];
    if (!h) { $('#' + id).innerHTML = '<p class="empty-box" style="margin:1rem">Mapa indisponível: a biblioteca não carregou (sem internet ou bloqueio). Recarregue a página.</p>'; return null; }
    return (maps[id] = Object.assign(h, { me: null, bound: false }));
  });
}
function resetMaps() { Object.keys(maps).forEach(id => { maps[id].destroy(); delete maps[id]; }); }
function syncMapSwitch(msg) { $$('.mapsel button').forEach(b => b.setAttribute('aria-pressed', b.dataset.prov === Maps.provider())); $$('.map-note').forEach(n => n.textContent = msg || ''); }
function redrawMaps() { if (view === 'solicitar' && step === 1) showStep(1); else if (view === 'acompanhar') renderTrack(); }
$$('.mapsel button').forEach(b => b.addEventListener('click', () => {
  const p = b.dataset.prov;
  if (p === 'google' && !Maps.googleConfigured()) return syncMapSwitch('Para usar o Google Maps, informe sua chave em js/config.js (GOOGLE_MAPS_API_KEY). Veja o README.');
  if (p === Maps.provider()) return; Maps.setProvider(p); resetMaps(); syncMapSwitch(); redrawMaps();
}));
Maps.onProblem = e => { syncMapSwitch(e.message === 'auth' ? 'O Google recusou a chave (confira faturamento, API ativada e restrições). Voltamos ao mapa aberto.' : 'Não foi possível carregar o Google Maps. Voltamos ao mapa aberto.'); resetMaps(); redrawMaps(); };
function km(a, b) { const R = 6371, r = x => x * Math.PI / 180, dLa = r(b.lat - a.lat), dLo = r(b.lng - a.lng);
  return 2 * R * Math.asin(Math.sqrt(Math.sin(dLa/2)**2 + Math.cos(r(a.lat)) * Math.cos(r(b.lat)) * Math.sin(dLo/2)**2)); }

// ---- Rascunho do pedido (sessionStorage; senha nunca é guardada) ----
const FIELDS = { 'f-marca':'marca','f-modelo':'modelo','f-ano':'ano','f-cor':'cor','f-placa':'placa','f-prob':'prob','f-tel':'tel','f-obs':'obs','ref':'ref','destino':'destino' };
function collect() { Object.entries(FIELDS).forEach(([id, k]) => draft[k] = $('#' + id).value.trim());
  const r = $('input[name=veic]:checked'); if (r) draft.veic = r.value; save(KEY, draft); }
function restore() { Object.entries(FIELDS).forEach(([id, k]) => { if (draft[k] != null) $('#' + id).value = draft[k]; });
  if (draft.origem) $('#origem').value = draft.origem.label || ''; const r = draft.veic && $(`input[name=veic][value="${draft.veic}"]`); if (r) r.checked = true; }
$$('.flow input, .flow select, .flow textarea').forEach(el => { if (el.id !== 'a-senha') el.addEventListener('input', () => { if (!el.id.startsWith('a-')) collect(); }); });

// ---- Localização ----
function setOrigin(lat, lng, label, opt = {}) {
  draft.origem = { lat, lng, label: label || draft.origem?.label || '' }; save(KEY, draft);
  if (label) { $('#origem').value = label; $('#pin-addr').textContent = label; }
  const o = maps['map-loc'];
  if (o && opt.recenter !== false) o.setView(lat, lng, 16);   // o pino fixo fica sobre o centro do mapa
  renderTrucks();
}
let revT, revC;                                                      // endereço do pino (Nominatim reverse, com debounce)
function reverse(lat, lng) {
  clearTimeout(revT); $('#pin-addr').textContent = 'Buscando endereço…';
  revT = setTimeout(async () => {
    revC?.abort(); revC = new AbortController();
    try {
      const j = await (await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=18&addressdetails=1&accept-language=pt-BR&lat=${lat}&lon=${lng}`, { signal: revC.signal })).json(), a = j.address || {};
      const lab = [[a.road, a.house_number].filter(Boolean).join(', '), a.suburb || a.neighbourhood, a.city || a.town || a.village].filter(Boolean).join(' - ') || j.display_name;
      if (lab && draft.origem && Math.abs(draft.origem.lat - lat) < 1e-9) setOrigin(lat, lng, lab, { recenter: false });
      else $('#pin-addr').textContent = 'Local marcado no mapa';
    } catch (e) { if (e.name !== 'AbortError') $('#pin-addr').textContent = 'Local marcado no mapa'; }
  }, 700);
}
function bindPicker(o) {
  o.on('dragstart', () => $('#center-pin').classList.add('lift'));
  o.on('dragend', () => { $('#center-pin').classList.remove('lift'); const c = o.center(); setOrigin(c.lat, c.lng, '', { recenter: false }); reverse(c.lat, c.lng); });
  o.on('click', p => { setOrigin(p.lat, p.lng, 'Local marcado no mapa'); reverse(p.lat, p.lng); });
}
$('#btn-locate').addEventListener('click', () => $('#btn-gps').click());
$('#btn-gps').addEventListener('click', () => {
  const m = $('#msg-busca');
  if (!navigator.geolocation) { m.textContent = 'Seu navegador não suporta GPS. Digite o endereço ou toque no mapa.'; return; }
  m.textContent = 'Aguardando sua autorização…'; m.classList.add('loading');
  navigator.geolocation.getCurrentPosition(
    p => { m.classList.remove('loading'); m.textContent = ''; const { latitude: la, longitude: lo } = p.coords; setOrigin(la, lo, 'Minha localização atual'); reverse(la, lo);
      const o = maps['map-loc']; if (o) { if (o.me) o.me.set(la, lo); else o.me = o.marker(la, lo, { kind: 'me', persist: true }); } },
    () => { m.classList.remove('loading'); m.textContent = 'Não foi possível obter o GPS. Digite o endereço ou toque no mapa.'; },
    { enableHighAccuracy: true, timeout: 10000 });
});
async function buscar() {
  const q = $('#origem').value.trim(), m = $('#msg-busca');
  if (!q) { m.textContent = 'Digite um endereço, bairro, cidade ou CEP.'; return; }
  m.textContent = 'Buscando…'; m.classList.add('loading');
  try {
    const j = await (await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=br&q=' + encodeURIComponent(q))).json();
    if (!j.length) { m.textContent = 'Endereço não encontrado. Tente outro ou toque no mapa.'; return; }
    m.textContent = ''; setOrigin(+j[0].lat, +j[0].lon, j[0].display_name);
  } catch { m.textContent = 'Erro de rede na busca. Tente novamente ou marque no mapa.'; } finally { m.classList.remove('loading'); }
}
$('#btn-buscar').addEventListener('click', buscar);
$('#origem').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); buscar(); } });

function renderTrucks() {
  const o = maps['map-loc']; if (o) o.clear();
  const ul = $('#lista'); ul.innerHTML = '';
  if (!draft.origem) { ul.innerHTML = '<li class="empty">Informe sua localização para ver os guinchos.</li>'; return; }
  const items = DEMO_TRUCKS.filter(t => t.available).map(t => ({ ...t, lat: draft.origem.lat + t.dLat, lng: draft.origem.lng + t.dLng }))
    .map(t => ({ ...t, dist: km(draft.origem, t) })).sort((a, b) => a.dist - b.dist);
  if (!items.length) { ul.innerHTML = '<li class="empty">Nenhum guincho disponível na sua região no momento.</li>'; return; }
  items.forEach(t => {
    if (o) o.marker(t.lat, t.lng, { kind: 'truck', popup: `${esc(t.name)} (demo)` });
    const li = document.createElement('li'), sel = draft.truck?.id === t.id;
    li.innerHTML = `<div class="avatar" aria-hidden="true">🚚</div><div class="info"><strong>${esc(t.name)}</strong> <span class="tag">DEMO</span><br><small>${esc(t.vehicle)} · ⭐ ${t.rating} · ~${t.dist.toFixed(1)} km (linha reta)</small></div>`;
    const b = document.createElement('button'); b.type = 'button'; b.className = 'btn ' + (sel ? 'primary' : 'ghost'); b.textContent = sel ? 'Escolhido ✓' : 'Preferir';
    b.setAttribute('aria-pressed', sel);
    b.addEventListener('click', () => { draft.truck = sel ? null : { id: t.id, name: t.name, lat: t.lat, lng: t.lng }; save(KEY, draft); renderTrucks(); });
    li.appendChild(b); ul.appendChild(li);
  });
}

// ---- Autenticação demonstrativa ----
function authUI() { $('#btn-auth').textContent = user ? 'Sair' : 'Entrar'; }
$('#btn-auth').addEventListener('click', () => { if (user) { user = null; sessionStorage.removeItem(SES); authUI(); location.hash = '#'; } else { step = 0; location.hash = '#/solicitar'; route(); } });
function setMode(m) { mode = m; $('#tab-login').setAttribute('aria-pressed', m === 'login'); $('#tab-cad').setAttribute('aria-pressed', m === 'cad');
  $('#g-nome').hidden = m === 'login'; $('#btn-auth-go').textContent = m === 'login' ? 'Entrar e continuar' : 'Criar conta e continuar'; $('#a-senha').autocomplete = m === 'login' ? 'current-password' : 'new-password'; }
$('#tab-login').addEventListener('click', () => setMode('login')); $('#tab-cad').addEventListener('click', () => setMode('cad'));
$('#f-auth').addEventListener('submit', e => {
  e.preventDefault(); const err = $('#auth-err'), em = $('#a-email').value.trim(), nome = $('#a-nome').value.trim(), s = $('#a-senha').value;
  if (mode === 'cad' && nome.length < 2) return err.textContent = 'Informe seu nome.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(em)) return err.textContent = 'E-mail inválido.';
  if (s.length < 8) return err.textContent = 'A senha deve ter ao menos 8 caracteres.';
  err.textContent = ''; $('#a-senha').value = '';          // a senha nunca é guardada
  user = { nome: nome || em.split('@')[0], email: em }; save(SES, user); authUI(); showStep(1);
});

// ---- Etapas ----
function showStep(n) {
  if (n > 0 && !user) n = 0; step = n;
  $$('.step').forEach((s, i) => s.hidden = i !== n);
  $$('#progress li').forEach((li, i) => { li.classList.toggle('on', i <= n); li.toggleAttribute('aria-current', i === n); });
  if (n === 1) mk('map-loc').then(o => {
    if (!o || step !== 1) return;
    if (!o.bound) { o.bound = true; bindPicker(o); }
    setTimeout(() => o.resize(), 60); if (draft.origem) setOrigin(draft.origem.lat, draft.origem.lng); else renderTrucks();
  });
  const h = $('#s' + n + ' h2'); if (h) h.focus({ preventScroll: true });
}
$$('[data-go]').forEach(b => b.addEventListener('click', () => { collect(); showStep(+b.dataset.go); }));
$('#go2').addEventListener('click', () => { collect(); if (!draft.origem) return $('#err1').textContent = 'Informe a localização do veículo (GPS, endereço ou mapa).'; $('#err1').textContent = ''; showStep(2); });
$('#go3').addEventListener('click', () => {
  collect(); const e = $('#err2'), y = new Date().getFullYear() + 1;
  if (!draft.veic) return e.textContent = 'Escolha o tipo de veículo.';
  if (draft.ano && !(/^\d{4}$/.test(draft.ano) && +draft.ano >= 1950 && +draft.ano <= y)) return e.textContent = 'Ano inválido.';
  if (!draft.prob) return e.textContent = 'Selecione o motivo do guincho.';
  if (!/^[\d\s()+-]{10,16}$/.test(draft.tel || '')) return e.textContent = 'Informe um telefone válido.';
  e.textContent = '';
  const rows = [['Retirada', draft.origem.label || `${draft.origem.lat.toFixed(5)}, ${draft.origem.lng.toFixed(5)}`], ['Referência', draft.ref], ['Destino', draft.destino], ['Veículo', [draft.veic, draft.marca, draft.modelo, draft.ano, draft.cor, draft.placa].filter(Boolean).join(' · ')], ['Motivo', draft.prob], ['Telefone', draft.tel], ['Obs.', draft.obs], ['Guincho preferido', draft.truck ? draft.truck.name + ' (demo)' : 'Qualquer disponível']];
  $('#resumo').innerHTML = rows.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v || '—')}</dd>`).join('');
  showStep(3);
});
$('#btn-confirma').addEventListener('click', e => {
  const b = e.currentTarget; if (b.disabled) return; b.disabled = true; b.innerHTML = '<span class="spin"></span>Enviando…';
  setTimeout(() => { draft.pedido = 'DEMO-' + Math.random().toString(36).slice(2, 8).toUpperCase(); trackIdx = 0; save(KEY, draft); b.disabled = false; b.textContent = 'Confirmar solicitação'; location.hash = '#/acompanhar'; }, 700);
});

// ---- Acompanhamento (simulado) ----
let anim = 0, seq = 0, rota = null, rotaKey = '';
const reduzir = matchMedia('(prefers-reduced-motion: reduce)').matches;
function setEta(t) { const el = $('#eta'); if (el) el.textContent = t || 'Disponível quando o guincho for confirmado'; }
async function carregarRota() {   // OSRM público (demonstração): rota real entre o pedido e um guincho SIMULADO
  const p = draft.origem, key = p.lat + ',' + p.lng + ',' + (draft.truck?.id || ''); if (rotaKey === key) return rota; rotaKey = key; rota = null;
  const t0 = draft.truck || { lat: p.lat + 0.01, lng: p.lng + 0.006 };
  try { const j = await (await fetch(`https://router.project-osrm.org/route/v1/driving/${t0.lng},${t0.lat};${p.lng},${p.lat}?overview=full&geometries=geojson`)).json();
    const r = j.routes?.[0]; if (r) rota = { pts: r.geometry.coordinates.map(([x, y]) => [y, x]), dist: r.distance, dur: r.duration }; } catch {}
  return rota;
}
function drawRota(o, r, p) {
  if (!r) { o.marker(p[0] + 0.01, p[1] + 0.006, { kind: 'truck', popup: 'Guincho (simulado)' }); o.setView(p[0], p[1], 14); setEta('Rota indisponível no momento'); return; }
  o.route(r.pts);
  const tm = o.marker(r.pts[0][0], r.pts[0][1], { kind: 'truck', popup: 'Guincho (simulado)' }), mob = innerWidth < 900;
  o.fit(r.pts, { tl: [mob ? 30 : 420, 40], br: [30, mob ? 300 : 40], maxZoom: 16 });
  const min = s => Math.max(1, Math.round(s / 60)), nota = ' (rota calculada; guincho simulado)';
  if (trackIdx >= 4) { const e = r.pts[r.pts.length - 1]; tm.set(e[0], e[1]); setEta('Chegou ao local'); return; }
  if (trackIdx < 3) { setEta(`~${min(r.dur)} min · ${(r.dist / 1000).toFixed(1)} km` + nota); return; }
  const T = reduzir ? 0 : 14000, t0 = performance.now(), n = r.pts.length - 1;   // animação acelerada (demonstração)
  const step = now => { const f = T ? Math.min(1, (now - t0) / T) : 1, x = f * n, i = Math.min(Math.floor(x), n - 1), A = r.pts[i], B = r.pts[i + 1] || A, k = x - i;
    tm.set(A[0] + (B[0] - A[0]) * k, A[1] + (B[1] - A[1]) * k);
    setEta(`~${min(r.dur * (1 - f))} min · ${(r.dist * (1 - f) / 1000).toFixed(1)} km` + nota); if (f < 1) anim = requestAnimationFrame(step); };
  anim = requestAnimationFrame(step);
}
function renderTrack() {
  const my = ++seq; cancelAnimationFrame(anim); $('#t-id').textContent = draft.pedido;
  $('#stepper').innerHTML = STATUS.map((s, i) => `<li class="${i < trackIdx ? 'done' : i === trackIdx ? 'now' : ''}">${esc(s[0])}</li>`).join('');
  $('#t-msg').textContent = STATUS[trackIdx][1];
  $('#t-info').innerHTML = [['Local', draft.origem.label || 'Ponto marcado'], ['Veículo', [draft.veic, draft.modelo].filter(Boolean).join(' · ')], ['Prestador', trackIdx >= 2 ? (draft.truck?.name || 'Guincho Demo') + ' (simulado)' : 'Aguardando']].map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('') + '<dt>Chegada</dt><dd id="eta"></dd>';
  setEta(null); $('#btn-sim').disabled = trackIdx >= STATUS.length - 1;
  mk('map-track').then(o => {
    if (!o || my !== seq) return;
    o.clear(); const p = [draft.origem.lat, draft.origem.lng];
    o.marker(p[0], p[1], { kind: 'pickup', popup: 'Local do veículo' }); setTimeout(() => o.resize(), 60);
    if (trackIdx < 2 || trackIdx >= 5) { o.setView(p[0], p[1], 16); return; }
    carregarRota().then(r => { if (my === seq) drawRota(o, r, p); });
  });
}
$('#btn-sim').addEventListener('click', () => { trackIdx++; renderTrack(); });
$('#btn-center').addEventListener('click', () => { const o = maps['map-track']; if (o && draft.origem) o.setView(draft.origem.lat, draft.origem.lng, 16); });
$('#btn-cancel').addEventListener('click', () => { if (confirm('Cancelar este atendimento?')) { draft = {}; sessionStorage.removeItem(KEY); restore(); location.hash = '#'; } });

// ---- Roteador por hash: #  |  #/solicitar  |  #/acompanhar  (âncoras como #como rolam na Home) ----
function route() {
  cancelAnimationFrame(anim); seq++;
  const h = location.hash; view = h === '#/solicitar' ? 'solicitar' : h === '#/acompanhar' ? (draft.pedido && draft.origem ? 'acompanhar' : 'solicitar') : 'home';
  $$('[data-view]').forEach(s => s.hidden = s.dataset.view !== view); $('#nav').classList.remove('open'); updateFab();
  if (view === 'solicitar') { if (draft.pedido) { delete draft.pedido; save(KEY, draft); } showStep(step); scrollTo(0, 0); }
  else if (view === 'acompanhar') { renderTrack(); scrollTo(0, 0); }
  else { const t = h.length > 1 && !h.startsWith('#/') ? document.getElementById(h.slice(1)) : null; t ? t.scrollIntoView() : scrollTo(0, 0); }
}
addEventListener('hashchange', route);

// ---- Cabeçalho, revelação, CTA móvel ----
const topbar = $('#top'); const onScroll = () => topbar.classList.toggle('scrolled', scrollY > 8);
addEventListener('scroll', onScroll, { passive: true }); onScroll();
$('#burger').addEventListener('click', e => { const o = $('#nav').classList.toggle('open'); e.currentTarget.setAttribute('aria-expanded', o); });
const io = 'IntersectionObserver' in window ? new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: .12 }) : null;
$$('.reveal').forEach(el => io ? io.observe(el) : el.classList.add('in'));
function updateFab() { $('#fab').classList.toggle('hide', view !== 'home' || heroSeen); }
if ('IntersectionObserver' in window) new IntersectionObserver(es => { heroSeen = es[0].isIntersecting; updateFab(); }, { threshold: .15 }).observe($('.hero'));
$$('.svc-btn').forEach(b => b.addEventListener('click', () => { if (b.dataset.veic) { draft.veic = b.dataset.veic; save(KEY, draft); restore(); } location.hash = '#/solicitar'; }));

restore(); authUI(); setMode('login'); syncMapSwitch(); route();
