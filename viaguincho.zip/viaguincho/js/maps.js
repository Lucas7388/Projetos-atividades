'use strict';
/* Camada de mapas: a mesma interface para Leaflet/OpenStreetMap e Google Maps.
 * Handle retornado por Maps.create(id, zoomPos): setView(lat,lng,z) getZoom() center() on(evt,fn) clear()
 * marker(lat,lng,{kind:'truck'|'pickup'|'me',popup,persist}) route(pts) fit(pts,{tl,br,maxZoom}) resize() destroy() */
const Maps = (() => {
  const cfg = window.REBOCA_CONFIG, SK = 'reboca.mapa';
  const saved = () => { try { return sessionStorage.getItem(SK); } catch { return null; } };
  const api = { onProblem: null };
  let provider = saved() || cfg.MAP_PROVIDER, gmLoad = null;
  if (provider === 'google' && !cfg.GOOGLE_MAPS_API_KEY) provider = 'leaflet';
  const CENTER = [-23.5505, -46.6333];

  // ---------- Leaflet + OpenStreetMap (padrão do Quick Start) ----------
  function leaflet(id, zoomPos) {
    if (typeof L === 'undefined') return null;
    const el = document.getElementById(id), m = L.map(id, { zoomControl: false }).setView(CENTER, 12);
    L.control.zoom({ position: zoomPos }).addTo(m);
    const attr = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>';
    const CARTO = 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', OSM = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
    const tiles = u => L.tileLayer(u, { maxZoom: 19, subdomains: 'abcd', attribution: attr }).addTo(m);
    const tl = tiles(CARTO); let erros = 0;   // OSM público bloqueia sem Referer: CARTO é o padrão, OSM só reserva
    tl.on('tileerror', () => { if (++erros === 3) { m.removeLayer(tl); tiles(OSM); } });
    const div = (html, s) => L.divIcon({ className: '', html, iconSize: [s, s], iconAnchor: [s / 2, s / 2] });
    const icons = { truck: () => div('<span class="truck-pin">🚚</span>', 40), pickup: () => div('<span class="pickup-pin"></span>', 26), me: () => div('<span class="me-dot"></span>', 18) };
    const layer = L.layerGroup().addTo(m), ro = new ResizeObserver(() => m.invalidateSize()); ro.observe(el);
    return {
      kind: 'leaflet', setView: (a, b, z) => m.setView([a, b], z), getZoom: () => m.getZoom(),
      center: () => { const c = m.getCenter(); return { lat: c.lat, lng: c.lng }; },
      on: (e, f) => e === 'click' ? m.on('click', ev => f({ lat: ev.latlng.lat, lng: ev.latlng.lng })) : m.on(e, f),
      clear: () => layer.clearLayers(),
      marker: (a, b, o = {}) => { const k = L.marker([a, b], { icon: icons[o.kind || 'pickup'](), interactive: !!o.popup, keyboard: false }).addTo(o.persist ? m : layer); if (o.popup) k.bindPopup(o.popup); return { set: (x, y) => k.setLatLng([x, y]), remove: () => k.remove() }; },
      route: pts => { L.polyline(pts, { color: '#fff', weight: 9, opacity: .95 }).addTo(layer); L.polyline(pts, { color: '#171717', weight: 5 }).addTo(layer); },
      fit: (pts, o) => m.fitBounds(L.latLngBounds(pts), { paddingTopLeft: o.tl, paddingBottomRight: o.br, maxZoom: o.maxZoom }),
      resize: () => m.invalidateSize(), destroy: () => { ro.disconnect(); m.remove(); }
    };
  }

  // ---------- Google Maps JavaScript API (exige chave; carregada só quando escolhida) ----------
  function loadGoogle() {
    if (window.google?.maps) return Promise.resolve();
    return gmLoad ||= new Promise((res, rej) => {
      window.__gmInit = res;
      window.gm_authFailure = () => { provider = 'leaflet'; api.onProblem?.(new Error('auth')); };   // chamado pelo Google se a chave for recusada
      const s = document.createElement('script');
      s.src = 'https://maps.googleapis.com/maps/api/js?key=' + encodeURIComponent(cfg.GOOGLE_MAPS_API_KEY) + '&callback=__gmInit&language=pt-BR&region=BR&v=weekly';
      s.async = true; s.onerror = () => { gmLoad = null; rej(new Error('load')); }; document.head.appendChild(s);
    });
  }
  async function google(id, zoomPos) {
    await loadGoogle();
    const gm = window.google.maps, el = document.getElementById(id), items = [], info = new gm.InfoWindow();
    const m = new gm.Map(el, { center: { lat: CENTER[0], lng: CENTER[1] }, zoom: 12, disableDefaultUI: true, zoomControl: true, gestureHandling: 'greedy', clickableIcons: false,
      zoomControlOptions: { position: zoomPos === 'topright' ? gm.ControlPosition.RIGHT_TOP : gm.ControlPosition.RIGHT_BOTTOM } });
    const dot = (fill, stroke, scale, w) => ({ path: gm.SymbolPath.CIRCLE, scale, fillColor: fill, fillOpacity: 1, strokeColor: stroke, strokeWeight: w });
    const look = { truck: { icon: dot('#fff', '#171717', 17, 2), label: { text: '🚚', fontSize: '18px' }, zIndex: 3 }, pickup: { icon: dot('#FF6B00', '#171717', 9, 3), zIndex: 2 }, me: { icon: dot('#1a73e8', '#fff', 8, 3), zIndex: 1 } };
    const P = (a, b) => ({ lat: a, lng: b });
    return {
      kind: 'google', setView: (a, b, z) => { m.setCenter(P(a, b)); if (z != null) m.setZoom(z); }, getZoom: () => m.getZoom(),
      center: () => { const c = m.getCenter(); return { lat: c.lat(), lng: c.lng() }; },
      on: (e, f) => e === 'click' ? m.addListener('click', ev => f({ lat: ev.latLng.lat(), lng: ev.latLng.lng() })) : m.addListener(e, f),
      clear: () => { items.forEach(i => i.setMap(null)); items.length = 0; },
      marker: (a, b, o = {}) => { const k = new gm.Marker({ map: m, position: P(a, b), ...look[o.kind || 'pickup'] }); if (!o.persist) items.push(k);
        if (o.popup) k.addListener('click', () => { info.setContent(o.popup); info.open({ map: m, anchor: k }); }); return { set: (x, y) => k.setPosition(P(x, y)), remove: () => k.setMap(null) }; },
      route: pts => { const path = pts.map(([a, b]) => P(a, b)); items.push(new gm.Polyline({ map: m, path, strokeColor: '#fff', strokeWeight: 9, strokeOpacity: .95 }), new gm.Polyline({ map: m, path, strokeColor: '#171717', strokeWeight: 5, zIndex: 2 })); },
      fit: (pts, o) => { const b = new gm.LatLngBounds(); pts.forEach(([a, c]) => b.extend(P(a, c))); m.fitBounds(b, { left: o.tl[0], top: o.tl[1], right: o.br[0], bottom: o.br[1] });
        gm.event.addListenerOnce(m, 'idle', () => { if (m.getZoom() > o.maxZoom) m.setZoom(o.maxZoom); }); },
      resize: () => gm.event.trigger(m, 'resize'), destroy: () => { el.innerHTML = ''; }
    };
  }

  Object.assign(api, {
    provider: () => provider, googleConfigured: () => !!cfg.GOOGLE_MAPS_API_KEY,
    setProvider(p) { provider = p; try { sessionStorage.setItem(SK, p); } catch {} },
    async create(id, zoomPos) {
      if (provider === 'google') { try { return await google(id, zoomPos); } catch (e) { provider = 'leaflet'; setTimeout(() => api.onProblem?.(e), 0); } }
      return leaflet(id, zoomPos);
    }
  });
  return api;
})();
