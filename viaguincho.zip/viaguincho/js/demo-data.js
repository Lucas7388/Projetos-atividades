// DADOS FICTÍCIOS (Etapa 1). Posições são deslocamentos relativos ao cliente,
// apenas para demonstrar a interface. Na Etapa 2 virão do banco (PostGIS).
const DEMO_TRUCKS = [
  { id: 'demo-1', name: 'Guincho Demo Alfa', vehicle: 'Plataforma', rating: 4.8, available: true,  dLat: 0.012,  dLng: 0.006 },
  { id: 'demo-2', name: 'Reboque Demo Beta', vehicle: 'Asa delta',  rating: 4.5, available: true,  dLat: -0.018, dLng: 0.011 },
  { id: 'demo-3', name: 'SOS Demo Gama',     vehicle: 'Plataforma', rating: 4.2, available: false, dLat: 0.025,  dLng: -0.02 }
];
